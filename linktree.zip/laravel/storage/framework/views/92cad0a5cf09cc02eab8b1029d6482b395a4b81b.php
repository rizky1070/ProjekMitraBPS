<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Inter:100,200,300,regular,500,600,700,800,900" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <title>Link SEKRETARIAT</title>
  </head>
  <body>
    <div class="d-lg-none">
        <img src="<?php echo e(asset('assets/image/Logo BPS Baru 2.png')); ?>" class="d-block mx-auto" width="256" alt="">
    </div>
    <div class="d-sm-none d-md-none d-lg-block d-smi-none">
        <img src="<?php echo e(asset('assets/image/Logo BPS Baru 2.png')); ?>" style="margin-left: 20px;" width="256" alt="">
    </div>
    <div class="container mt-5">
        <div class="row d-flex justify-content-center">
            
            <nav class="ml-auto" style="margin-top: -140px; margin-right: 10px">
                <div class="logo"></div>
                <ul>
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger">LogOut</button>
                        </form>
                        <li><a href="<?php echo e(route('links.index')); ?>">Menu Admin</a></li>
                        <li><a href="<?php echo e(route('link-user')); ?>">PRIBADI</a></li>
                        <li><a href="<?php echo e(route('link-kantor')); ?>">SUPER TIM</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Log In</a></li>
                    <?php endif; ?>
                </ul>
                <div class="menu-toggle" onclick="toggle()">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </nav>
        </div>
        <div class="col-md-12" style="margin-top: -70px">
            <?php if(auth()->guard()->check()): ?>
                <div class="mt-4"></div>
                <div class="rounded-border-2 mx-auto">
                    <h1 class="text-center h1-text">SEKRETARIAT</h1>
                </div>
            <?php endif; ?>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div class="mt-5"></div>
                <div class="mt-2"></div>
                <div class="seperti-itu mt-3">
                    
                    
                    <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($cat->ketuas->count() != null): ?>
                            <?php if($cat->ketuas->count() != null): ?>
                                <div class="text pt-4 pb-2">
                                    <h1 class="text-h1 text-center"><?php echo e($cat->name); ?></h1>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $cat->ketuas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($link->name != null): ?>
                                <?php if(strpos($link->link, 'http') === 0 || strpos($link->link, 'https') === 0): ?>
                                    <a target="_blank" href="<?php echo e($link->link); ?>" class="luweh-emboh emboh">
                                        <p class="text-emboh text-embohparah"><?php echo e($link->name); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a target="_blank" href="https://<?php echo e($link->link); ?>" class="luweh-emboh emboh">
                                        <p class="text-emboh text-embohparah"><?php echo e($link->name); ?></p>
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(strpos($link->link, 'http') === 0 || strpos($link->link, 'https') === 0): ?>
                                    <a target="_blank" href="<?php echo e($link->link); ?>" class="luweh-emboh emboh">
                                        <p class="text-emboh text-embohparah"><?php echo e($link->link); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a target="_blank" href="https://<?php echo e($link->link); ?>" class="luweh-emboh emboh">
                                        <p class="text-emboh text-embohparah"><?php echo e($link->link); ?></p>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="luweh-emboh emboh">
                            <p class="text-emboh text-embohparah">User belum memiliki link</p>
                        </a>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div class="mt-5"></div>
                <div class="mt-2"></div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <script>
        const nav = document.querySelector('nav ul');
        function toggle() {
            nav.classList.toggle('slide');
        }
    </script>
  </body>
</html><?php /**PATH /home/u1585795/public_html/laravel/resources/views/page/users/ketua.blade.php ENDPATH**/ ?>