<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; BPS Kabupaten Mojokerto</span>
        </div>
    </div>
</footer><?php /**PATH E:\app\laravel\linktree\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>