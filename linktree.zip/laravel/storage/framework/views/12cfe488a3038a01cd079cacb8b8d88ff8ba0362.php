

<?php $__env->startSection('title'); ?>
    edit admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Edit office link</h1>
</div>

<!-- Content Row -->
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit link</div>
						<a href="<?php echo e(route('office.index')); ?>" class="btn btn-primary btn-sm ml-auto">Back</a>
					</div>
				</div>
				
				<div class="card-body">
					<form action="<?php echo e(route('office.update', $office->id)); ?>" method="POST" enctype="multipart/form-data">
						<?php echo method_field('PUT'); ?>
						<?php echo csrf_field(); ?>
						<div class="form-group">
							<label for="judul">Link Placeholder</label>
							<input type="text" value="<?php echo e($office->name); ?>" class="form-control" name="name">
						</div>
						<div class="form-group">
							<label for="judul">Link</label>
							<input type="text" value="<?php echo e($office->link); ?>" class="form-control" name="link">
						</div>
						<div class="form-group">
							<label for="">Category</label>
							<select class="form-control" name="category_id" id="">
								<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(old('category_id', $office->category_id) == $cat->category_id): ?>
									<option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
								<?php else: ?>
									<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
                            <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        </div>
					</form>
				</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\laravel\linktree\resources\views/page/admin/office/edit.blade.php ENDPATH**/ ?>