

<?php $__env->startSection('title'); ?>
    edit admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Edit user</h1>
</div>

<!-- Content Row -->
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit users</div>
						<a href="<?php echo e(route('link-user')); ?>" class="btn btn-primary btn-sm ml-auto">Back</a>
					</div>
				</div>
				
				<div class="card-body">
					<form action="<?php echo e(route('updateuser', $users->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
						<?php echo csrf_field(); ?>
						<?php if($message = Session::get('gagal')): ?>
							<div class="alert alert-danger">
								<button type="button" class="close" data-dismiss="alert">×</button> 
								<strong><?php echo e($message); ?></strong>
							</div>
						<?php endif; ?>
						<div class="form-group">
							<label for="">Name</label>
							<input type="text" class="form-control" name="name" value="<?php echo e($users->name); ?>">
						</div>
						<div hidden>
							<input type="text" name="roles" value="<?php echo e($users->roles); ?>">
						</div>
                        <div class="form-group">
							<label for="judul">username</label>
							<input type="text" value="<?php echo e($users->username); ?>" class="form-control" name="username">
						</div>
						<div class="form-group">
							<label for="judul">Password</label>
							<input type="text" class="form-control" name="password">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1585795/public_html/laravel/resources/views/page/users/edit.blade.php ENDPATH**/ ?>