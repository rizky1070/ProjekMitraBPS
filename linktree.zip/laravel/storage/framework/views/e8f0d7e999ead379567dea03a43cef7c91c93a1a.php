<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->roles); ?> | <?php echo e(Auth::user()->name); ?></span>
                <img class="img-profile rounded-circle"
                    src="<?php echo e(url('backend/img/undraw_profile.svg')); ?>">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="userDropdown">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" type="submit">Log Out</button>
                </form>
                <a href="<?php echo e(route('edit-user')); ?>" class="btn btn-primary mt-2">Edit Profile</a>
            </div>
        </li>

    </ul>

</nav><?php /**PATH /home/u1585795/public_html/laravel/resources/views/includes/admin/navbar.blade.php ENDPATH**/ ?>