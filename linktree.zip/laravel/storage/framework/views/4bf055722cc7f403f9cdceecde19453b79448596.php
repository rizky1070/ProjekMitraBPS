

<?php $__env->startSection('title'); ?>
    Link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Link</h1>
    <a href="<?php echo e(route('link-kantor')); ?>" class="btn btn-primary">Go To Home</a>
    <a href="<?php echo e(route('ketua.create')); ?>" class="btn btn-primary">Tambah Data</a>
</div>

<!-- Content Row -->
<div class="container">
    <form method="GET">
        <div class="form-group mb-5">
          <input 
            type="text" 
            name="search" 
            value="<?php echo e(request()->get('search')); ?>" 
            class="form-control" 
            placeholder="Search..." 
            aria-label="Search" 
            aria-describedby="button-addon2">
          <button class="btn btn-success mt-3" type="submit" id="button-addon2">Search</button>
        </div>
    </form>
    <div class="table-responsive">
        <?php if($ketua->count()): ?>
            <table class="table table-bordered">
                <tr>
                    <th>Placeholder</th>
                    <th>Links</th>
                    <th>Category</th>
                    <th class="text-center">Aksi</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $ketua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <?php if($row->name == null): ?>
                            <th>Belum ada placeholder</th>
                        <?php else: ?>
                            <th><?php echo e($row->name); ?></th>
                        <?php endif; ?>
                        <th><?php echo e($row->link); ?></th>
                        <th><?php echo e($row->category->name); ?></th>
                        <th class="text-center">
                            <form action="<?php echo e(route('ketua.edit', $row->id)); ?>" class="d-inline">
                                <?php echo method_field('PUT'); ?>
                                <button class="btn btn-primary">
                                    Edit
                                </button>
                            </form> |
                            <form action="<?php echo e(route('ketua.destroy', $row->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger">
                                    Hapus
                                </button>

                            </form>
                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td colspan="4" class="text-center">Data Masih Kosong!</td>
                <?php endif; ?>
            </table>
        <?php else: ?>
            <h1 class="text-center mt-5">Data tidak ditemukan</h1>
        <?php endif; ?>
        <?php if(request()->get('search') == null && empty(request()->get('showAll'))): ?>
            <?php echo e($ketua->links()); ?>

            <form method="GET">
                <div class="form-group">
                    <input type="hidden" value="showAll" name="showAll">
                    <button class="btn btn-success mt-3" type="submit" id="button-addon2">Show All</button>
                </div>
            </form>
        <?php elseif(empty(request()->get('search'))): ?>
            <form method="GET">
                <div class="form-group">
                    <input type="hidden" value="showAll" name="showAll">
                    <button class="btn btn-success mt-3" type="submit" id="button-addon2">Show All</button>
                </div>
            </form>
        <?php else: ?>
            
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\laravel\linktree\resources\views/page/admin/ketua/index.blade.php ENDPATH**/ ?>