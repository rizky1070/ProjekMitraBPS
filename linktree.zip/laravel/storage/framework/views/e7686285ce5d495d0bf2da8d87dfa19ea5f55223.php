

<?php $__env->startSection('title'); ?>
    edit admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Edit user</h1>
</div>

<!-- Content Row -->
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit users</div>
						<a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-sm ml-auto">Back</a>
					</div>
				</div>
				
				<div class="card-body">
					<form action="<?php echo e(route('users.update', $users->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
						<?php echo csrf_field(); ?>
						<?php if($message = Session::get('gagal')): ?>
							<div class="alert alert-danger">
								<button type="button" class="close" data-dismiss="alert">×</button> 
								<strong><?php echo e($message); ?></strong>
							</div>
						<?php endif; ?>
                        <div class="form-group">
							<label for="judul">username</label>
							<input type="text" value="<?php echo e($users->username); ?>" class="form-control" name="username">
						</div>
						<div class="form-group">
							<label for="judul">Nama</label>
							<input type="text" value="<?php echo e($users->name); ?>" class="form-control" name="name">
						</div>
						<div class="form-group">
							<label for="judul">Password</label>
							<input type="text" class="form-control" name="password">
                        </div>
						<div class="form-group">
							<label for="judul">Roles</label>
							<select name="roles" id="">
								<?php if(old('roles', $users->roles) == $roles): ?>
									<option value="<?php echo e($roles); ?>" selected><?php echo e($roles); ?></option>
								<?php else: ?>
									<option value="ADMIN">Admin</option>
									<option value="USER">User</option>
									<option value="SEKRETARIAT">Sekretariat</option>
								<?php endif; ?>
							</select>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1585795/public_html/laravel/resources/views/page/admin/users/edit.blade.php ENDPATH**/ ?>