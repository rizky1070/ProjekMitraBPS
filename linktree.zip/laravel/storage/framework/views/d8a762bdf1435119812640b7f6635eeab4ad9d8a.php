<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-toolbox"></i>
        </div>
        <?php if(Auth::user()->roles == 'ADMIN'): ?>
            <a href="<?php echo e(route('dashboard')); ?>"><div class="text-center mb-3" style="color: white">Admin</div></a>
        <?php elseif(Auth::user()->roles == 'SEKRETARIAT'): ?>
            <a href="<?php echo e(route('dashboard')); ?>"><div class="text-center mb-3" style="color: white">Sekretariat</div></a>
        <?php else: ?>
            <a href="<?php echo e(route('dashboard')); ?>"><div class="text-center mb-3" style="color: white">User</div></a>
        <?php endif; ?>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <?php if(Auth::user()->roles == 'ADMIN'): ?>
        <!-- Nav Item - Dashboard -->
        <li class="nav-item <?php echo e(Request::is('admin*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                <i class="fas fa-fw fa-vote-yea"></i>
                <span>User</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('links*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('links.index')); ?>">
                <i class="fas fa-fw fa-people-arrows"></i>
                <span>My Links</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('office*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('office.index')); ?>">
                <i class="fas fa-fw fa-people-arrows"></i>
                <span>Link General Office</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('sekretariat*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('sekretariat.index')); ?>">
                <i class="fas fa-fw fa-people-arrows"></i>
                <span>Link Sekretariat</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('category') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('category.index')); ?>">
                <i class="fas fa-fw fa-people-arrows"></i>
                <span>Category Link Office & Sekretariat</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::is('categoryuser*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('categoryuser.index')); ?>">
                <i class="fas fa-fw fa-people-arrows"></i>
                <span>Category Link User</span></a>
        </li>
    <?php else: ?>
    <li class="nav-item <?php echo e(Request::is('admin*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>
    <li class="nav-item <?php echo e(Request::is('links*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('links.index')); ?>">
            <i class="fas fa-fw fa-people-arrows"></i>
            <span>Links</span></a>
    </li>
    <li class="nav-item <?php echo e(Request::is('categoryuser*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('categoryuser.index')); ?>">
            <i class="fas fa-fw fa-people-arrows"></i>
            <span>Category Link User</span></a>
    </li>
    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul><?php /**PATH E:\DOWNLOAD\laravel\resources\views/includes/admin/sidebar.blade.php ENDPATH**/ ?>