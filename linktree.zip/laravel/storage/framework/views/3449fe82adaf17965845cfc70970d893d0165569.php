

<?php $__env->startSection('title'); ?>
    Link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">PRIBADI</h1>
    <a href="<?php echo e(route('link-kantor')); ?>" class="btn btn-primary">Home</a>
    <a href="<?php echo e(route('links.create')); ?>" class="btn btn-primary">Tambah Link</a>
</div>

<!-- Content Row -->
<div class="container">
    <form method="GET">
        <div class="form-group mb-5">
          <input 
            type="text" 
            name="search" 
            value="<?php echo e(request()->get('search')); ?>" 
            class="form-control" 
            placeholder="Search..." 
            aria-label="Search" 
            aria-describedby="button-addon2">
          <button class="btn btn-success mt-3" type="submit" id="button-addon2">Search</button>
        </div>
    </form>
    <div class="table-responsive">
        <?php if($links->count()): ?>
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Judul Link</th>
                    <th>Kategori</th>
                    <th>Ditampilkan</th>
                    <th class="text-center">Aksi</th>
                </tr>
                <tbody>
<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="row-<?php echo e($row->id); ?>">
<th class="text-center" id="row"><?php echo e($loop->iteration); ?>.</th>
<th><?php echo e($row->name); ?></th>
<th><?php echo e($row->category->name); ?></th>
<td> <a class="btn btn-sm btn-<?php echo e($row->status ? 'success' : 'danger'); ?>">
                    <?php echo e($row->status ? 'Ya' : 'Tidak'); ?></a> </td>

                        <th class="text-center">
                            <form action="<?php echo e(route('links.edit', $row->id)); ?>" class="d-inline">
                                <?php echo method_field('PUT'); ?>
                                <button class="btn btn-primary">
                                    Edit
                                </button>
                            </form> |
                            <form action="<?php echo e(route('links.destroy', $row->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger">
                                    Hapus
                                </button>

                            </form>
                        </th>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
            </table>
        <?php else: ?>
            <h1 class="text-center mt-5">Anda belum menginput link pribadi. Hanya orang yang login menggunakan akun ini yang bisa melihat link pribadi yang telah dibuat. Cobalah buat, misal link2 web yang sering diakses dan susah dihafal. Sebelumnya buat kategori pribadi dulu-->input link pribadi. tks</h1>
        <?php endif; ?>
        <?php if(request()->get('search') == null && empty(request()->get('showAll'))): ?>
            <?php echo e($links->links()); ?>

            <form method="GET">
                <div class="form-group">
                    <input type="hidden" value="showAll" name="showAll">
                    <button class="btn btn-success mt-3" type="submit" id="button-addon2">Show All</button>
                </div>
            </form>
        <?php elseif(empty(request()->get('search'))): ?>
            <form method="GET">
                <div class="form-group">
                    <input type="hidden" value="showAll" name="showAll">
                    <button class="btn btn-success mt-3" type="submit" id="button-addon2">Show All</button>
                </div>
            </form>
        <?php else: ?>
            
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1585795/public_html/laravel/resources/views/page/admin/links/index.blade.php ENDPATH**/ ?>