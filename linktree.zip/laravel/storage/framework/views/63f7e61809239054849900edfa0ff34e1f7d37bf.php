<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; Tim Dilan 2022 - <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH /home/u1585795/public_html/laravel/resources/views/includes/admin/footer.blade.php ENDPATH**/ ?>